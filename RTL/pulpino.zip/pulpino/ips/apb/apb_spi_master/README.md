# APB SPI Master

This IP depends on the AXI SPI master since it uses the same SPI logic. Instead
of an AXI bus this IP uses an APB bus.
