# AXI SPI Master

This is an implementation of an SPI master that is controlled via an AXI bus.
It has FIFOs for transmitting and receiving data.  It supports both the normal
SPI mode and QPI mode with 4 data lines.
This IP was written for the use in the [PULP platform](http://pulp.ethz.ch/).
